package com.srms.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionProvider {
	private static Connection con=null;  
	static{
		String DRIVER="com.mysql.jdbc.Driver";  
		String CONNECTION_URL="jdbc:mysql://localhost:3306/srms";  
		String USERNAME="imtyaz";  
		String PASSWORD="imty@z";
		
		try {
			Class.forName(DRIVER);
			con =  DriverManager.getConnection(CONNECTION_URL,USERNAME,PASSWORD);
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	public static Connection getConnection() {
		return con;
	}
}
