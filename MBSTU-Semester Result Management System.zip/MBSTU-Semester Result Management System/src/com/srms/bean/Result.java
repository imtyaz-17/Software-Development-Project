package com.srms.bean;

public class Result {
private int id,cid,marks,courseCredit;
private String sid,semester,lettergrade;
private Double gradepoint;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
public int getCourseCredit() {
	return courseCredit;
}
public void setCourseCredit(int courseCredit) {
	this.courseCredit = courseCredit;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getSemester() {
	return semester;
}
public void setSemester(String semester) {
	this.semester = semester;
}
public String getLettergrade() {
	return lettergrade;
}
public void setLettergrade(String lettergrade) {
	this.lettergrade = lettergrade;
}
public Double getGradepoint() {
	return gradepoint;
}
public void setGradepoint(Double gradepoint) {
	this.gradepoint = gradepoint;
}


}
