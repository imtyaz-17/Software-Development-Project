package com.srms.bean;

public class Cgpa {
	private String sid,semester,gpa;
	private int totalCredit,earnCredit;
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getGpa() {
		return gpa;
	}
	public void setGpa(String gpa) {
		this.gpa = gpa;
	}
	public int getTotalCredit() {
		return totalCredit;
	}
	public void setTotalCredit(int totalCredit) {
		this.totalCredit = totalCredit;
	}
	public int getEarnCredit() {
		return earnCredit;
	}
	public void setEarnCredit(int earnCredit) {
		this.earnCredit = earnCredit;
	}
	
	
}
